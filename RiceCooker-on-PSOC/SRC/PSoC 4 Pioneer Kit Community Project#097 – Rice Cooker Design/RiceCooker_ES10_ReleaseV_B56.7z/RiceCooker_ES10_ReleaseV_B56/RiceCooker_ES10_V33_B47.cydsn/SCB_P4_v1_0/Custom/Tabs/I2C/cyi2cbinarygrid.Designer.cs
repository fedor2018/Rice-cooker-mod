namespace SCB_P4_v1_0
{
    partial class CyBinaryGrid
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBit0 = new System.Windows.Forms.Label();
            this.lblBit1 = new System.Windows.Forms.Label();
            this.lblBit2 = new System.Windows.Forms.Label();
            this.lblBit3 = new System.Windows.Forms.Label();
            this.lblBit4 = new System.Windows.Forms.Label();
            this.lblBit5 = new System.Windows.Forms.Label();
            this.lblBit6 = new System.Windows.Forms.Label();
            this.lblBit7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblBit0
            // 
            this.lblBit0.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit0.Location = new System.Drawing.Point(147, 0);
            this.lblBit0.Name = "lblBit0";
            this.lblBit0.Size = new System.Drawing.Size(15, 20);
            this.lblBit0.TabIndex = 26;
            this.lblBit0.Text = "0";
            this.lblBit0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit0.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit0.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit1
            // 
            this.lblBit1.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit1.Location = new System.Drawing.Point(126, 0);
            this.lblBit1.Name = "lblBit1";
            this.lblBit1.Size = new System.Drawing.Size(15, 20);
            this.lblBit1.TabIndex = 27;
            this.lblBit1.Text = "0";
            this.lblBit1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit1.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit1.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit2
            // 
            this.lblBit2.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit2.Location = new System.Drawing.Point(105, 0);
            this.lblBit2.Name = "lblBit2";
            this.lblBit2.Size = new System.Drawing.Size(15, 20);
            this.lblBit2.TabIndex = 28;
            this.lblBit2.Text = "0";
            this.lblBit2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit2.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit2.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit3
            // 
            this.lblBit3.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit3.Location = new System.Drawing.Point(84, 0);
            this.lblBit3.Name = "lblBit3";
            this.lblBit3.Size = new System.Drawing.Size(15, 20);
            this.lblBit3.TabIndex = 29;
            this.lblBit3.Text = "0";
            this.lblBit3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit3.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit3.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit4
            // 
            this.lblBit4.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit4.Location = new System.Drawing.Point(63, 0);
            this.lblBit4.Name = "lblBit4";
            this.lblBit4.Size = new System.Drawing.Size(15, 20);
            this.lblBit4.TabIndex = 30;
            this.lblBit4.Text = "0";
            this.lblBit4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit4.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit4.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit5
            // 
            this.lblBit5.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit5.Location = new System.Drawing.Point(42, 0);
            this.lblBit5.Name = "lblBit5";
            this.lblBit5.Size = new System.Drawing.Size(15, 20);
            this.lblBit5.TabIndex = 31;
            this.lblBit5.Text = "0";
            this.lblBit5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit5.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit5.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit6
            // 
            this.lblBit6.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit6.Location = new System.Drawing.Point(21, 0);
            this.lblBit6.Name = "lblBit6";
            this.lblBit6.Size = new System.Drawing.Size(15, 20);
            this.lblBit6.TabIndex = 32;
            this.lblBit6.Text = "0";
            this.lblBit6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit6.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit6.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // lblBit7
            // 
            this.lblBit7.BackColor = System.Drawing.SystemColors.Window;
            this.lblBit7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBit7.Location = new System.Drawing.Point(0, 0);
            this.lblBit7.Name = "lblBit7";
            this.lblBit7.Size = new System.Drawing.Size(15, 20);
            this.lblBit7.TabIndex = 33;
            this.lblBit7.Text = "0";
            this.lblBit7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBit7.TextChanged += new System.EventHandler(this.lblBit_TextChanged);
            this.lblBit7.Click += new System.EventHandler(this.lblBit_Click);
            // 
            // CyI2CP4FFBinaryGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblBit7);
            this.Controls.Add(this.lblBit6);
            this.Controls.Add(this.lblBit5);
            this.Controls.Add(this.lblBit4);
            this.Controls.Add(this.lblBit3);
            this.Controls.Add(this.lblBit2);
            this.Controls.Add(this.lblBit1);
            this.Controls.Add(this.lblBit0);
            this.Name = "CyI2CP4FFBinaryGrid";
            this.Size = new System.Drawing.Size(166, 20);
            this.Load += new System.EventHandler(this.CyI2CP4FFBinaryGrid_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblBit0;
        private System.Windows.Forms.Label lblBit1;
        private System.Windows.Forms.Label lblBit2;
        private System.Windows.Forms.Label lblBit3;
        private System.Windows.Forms.Label lblBit4;
        private System.Windows.Forms.Label lblBit5;
        private System.Windows.Forms.Label lblBit6;
        private System.Windows.Forms.Label lblBit7;

    }
}
