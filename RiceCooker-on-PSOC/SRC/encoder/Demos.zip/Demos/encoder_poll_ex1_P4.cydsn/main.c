/* ========================================
 *  Software implementation of Rotary Encoder with a Button Switch
 *  using pins polling method
 *
 *  Original idea:
 *  M.Kellett, Interfacing uc with Shaft Encoders.pdf 
 *  www.mkesc.co.uk/ise.pdf

 *  Software rotary encoder routines:
 *
 *  using Oleg @ CircuitsAtHome 
 *  http://www.circuitsathome.com/mcu/programming/reading-rotary-encoder-on-arduino (link is dead..)
 *  https://www.ccsinfo.com/forum/viewtopic.php?t=41115
 *   
 * ========================================
*/


#include <project.h>
#include <stdlib.h>
#include <stdio.h>


#define BlinkLED(); {Pin_LED_Write(0); CyDelayUs(100); Pin_LED_Write(1);} // blink LED indicator

//============================================
// Global variables
//============================================

char buff[64];//output UART buffer

//============================================
// Forward declarations
//============================================
void DisplayData(void); // output to terminal




void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    
    UART_1_Start();                    // initialize USBUART
    CyDelay(250);
    
    sprintf(buff, "\n%s", "Rotary encoder example\r\n");
    UART_1_UartPutString(buff);     // Send data to terminal
    
    DisplayData();
    BlinkLED();
    
    Decoder_1_Start();
    
}


int main()
{
    
    Initialize();
     
    
    for(;;) 
    {
        
        if (Decoder_1_PositionChanged)
        {
            DisplayData();            // output to terminal
            BlinkLED();               // debug..   
        }
        
        
        if (Decoder_1_BtnPressed)
        {
            Decoder_1_SetPosition(0); // some action
            BlinkLED();               // debug..              
        }
        
    }


    
} //main



//==============================================================================
// 
//==============================================================================

void DisplayData(void) // output to terminal
{    
    sprintf(buff, "%d \t%d \r\n", Decoder_1_Position, Decoder_1_Direction); // ok: int16, uint16
    UART_1_UartPutString(buff);              // Send data to PC      
}





/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////

